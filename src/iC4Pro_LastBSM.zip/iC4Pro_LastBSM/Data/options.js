const options = [
    { label: "femi.ademola@test.com", id: "femi.ademola@test.com"},
    { label: "kehinde@test.com", id: "kehinde@test.com"},
    { label: "joy@test.com", id: "joy@test.com"},
    { label: "eoliseh@test.com", id: "eoliseh@test.com"},
    { label: "ibkakin@test.com", id: "ibkakin@test.com"},
    { label: "tayo@test.com", id: "tayo@test.com"},
    { label: "chinedu@test.com",id: "chinedu@test.com"},
    { label: "young@test.com", id: "young@test.com"},
    { label: "ayoadeleke@test.com", id: "ayoadeleke@test.com"},
    { label: "binde@test.com", id: "binde@test.com"},
    { label: "trust@test.com", id: "trust@test.com"},
    { label: "yemi.yak@test.com", id: "yemi.yak@test.com"},
];

export {options};